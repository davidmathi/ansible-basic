#!/bin/bash

/usr/bin/uptime > /home/ansi/upt.loh
